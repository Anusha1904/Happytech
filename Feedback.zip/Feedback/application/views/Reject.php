
	<main>

  <section class="py-5 text-center container">
    <div class="row py-lg-5">
	<div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3">Accept</button>
  </div>
  <div class="col-auto">
    <button type="submit" class="btn btn-primary mb-3">Reject</button>
  </div>
      <div class="col-lg-6 col-md-8 mx-auto">
        <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
  </div>
  <div class="col-auto">
    <label for="inputPassword6" class="col-form-label">Password</label>
  </div>
  <div class="col-auto">
    <input type="password" id="inputPassword6" class="form-control" aria-describedby="passwordHelpInline">
  </div>
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
      </div>
    </div>
  </section>


