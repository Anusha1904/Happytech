
<body>
<form action="../Postjob/addnew/" method="post">
<div class="container-lg">
    
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2><b>Job Applicants Details</b></h2></div>
                    
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                       
                        <th>Applicant Name</th>
                        <th>Job Id</th>						
                        <th>Position Applied</th>
						<th>CV</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>                       
                        <td>Anusha Mandalapu</td>
                        <td>12345</td>
						 <td>Developer</td>
						 <th><a href="">Anusha.resume</a></th>
                        <td>
                            <a href="http://localhost:8080/Feedback/index.php/Evaluation/feedback/" class="btn btn-success my-2">Accept</a>
                            <a href="http://localhost:8080/Feedback/index.php/Evaluationreject/reject/" class="btn btn-danger my-2">Reject</a>
                        </td>
                    </tr>
                    <tr>
                        
                        <td>Sai</td>
                        <td>45678</td>
						<td>Manager</td>
						<th><a href="">sai.resume</a></th>
                        <td>
                             <a href="http://localhost:8080/Feedback/index.php/Evaluation/feedback/" class="btn btn-success my-2">Accept</a>
                            <a href="http://localhost:8080/Feedback/index.php/Evaluationreject/reject/" class="btn btn-danger my-2">Reject</a>
                        </td>
                    </tr>
                  </tbody>
            </table>
        </div>
    </div>
</div>     
</body>
