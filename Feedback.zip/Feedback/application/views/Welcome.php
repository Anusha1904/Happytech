
<main>

  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">Welcome To HappyTech</h1>
        <p class="lead text-muted">There is a growing need for organizations to develop intelligence across all business functions. Read more in our latest whitepaper about the emerging trends </p>
        <p>
		<a href="http://localhost:8080/Feedback/index.php/Postjob/post/" class="btn btn-info my-2">Post Job</a>
          <a href="http://localhost:8080/Feedback/index.php/Viewapplication/view/" class="btn btn-info my-2">View Applications</a>
          
          </p>
      </div>
    </div>
  </section>

  
</main>

