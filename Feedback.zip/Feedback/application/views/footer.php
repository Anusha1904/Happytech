<footer class="text-muted py-5">
  <div class="container">
       <p class="mb-1">All rights reserved @2021 Info Edge(UK)Ltd.</p>   
  </div>
</footer>
    <script src="<link href =<?php echo base_url(); ?>js/bootstrap.bundle.min.js>"></script>
  </body>
</html>
