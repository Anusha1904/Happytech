<main>

<div class="container mt-4 shadow-lg">
<div class="row">

<div class = "col-md-10">
<h2 class="text-center">Feedback Form</h2>
<hr>

    <form action="" method="post">
		<h4>Feedback Type</h2>
		
			<div class="form-group">
        	<input type="text" class="form-control" name="username" placeholder="Candidate Name" required="required">
        </div>
        <div class="form-group">
        	<input type="text" class="form-control" name="interviewer name" placeholder="Interviewer Name" required="required">
        </div>
		<div class="form-group">
            <input type="text" class="form-control" name="date" placeholder="Date of Interview" required="required">
        </div>
		<div class="form-group">
            <label for="job title">Job Title</label>
			<select name="job title" id="title">
    <option value="volvo">Developer</option>
    <option value="saab">Accountant</option>
    <option value="opel">Assistant Manager</option>
    <option value="audi">Team Lead</option>
  </select>
        </div>        
		<hr>
		<div class="row">
			<div class="col-md-4">
				<input type="radio"  name="position" class="pointer" required="required">&nbsp;&nbsp;<label>CV Evaluation</label>
				</div>
				<div class="col-md-4">
				<input type="radio"  name="position" class="pointer" required="required">&nbsp;&nbsp;<label>Technical Interview</label>
				</div>
				<div class="col-md-4">
				<input type="radio"  name="position" class="pointer" required="required">&nbsp;&nbsp;<label>HR Interview</label>
				</div>
			</div> 
			<hr>
			<div class="row">
			<div class="form-group col-md-10">
			<h5>Reviewer Comments</h5>
			<textarea id="comments" name="employer comments" class="form-control" placeholder="Reviewer Comments"></textarea>
			</div>
			</div>
			<h6>Hiring Recommendation after Completion of Interview</h6>
		<div class="row">
		<div class="col-md-2">
				<input type="radio"  name="position" class="pointer" required="required">&nbsp;&nbsp;<label>Hire</label>
				</div>
					<div class="col-md-2">
				<input type="radio"  name="position" class="pointer" required="required">&nbsp;&nbsp;<label>Not Hire</label>
				</div>
			</div> 
        <div class="form-group">
            <button type="submit" class="btn btn-success btn-lg btn-block">Send Feedback</button>
        </div>	
		
      </div>
	  </div>
	  </div>
