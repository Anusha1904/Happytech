<main>

<div class="container mt-4 shadow-lg">
<div class="row">

<div class = "col-md-10">
<h2 class="text-center btn btn-danger my-2">Application Rejected</h2>

<form action="<?php echo base_url(); ?>index.php/Evaluationreject/evaluationreject/" method="POST">


		<div class="form-group">
        	<input type="text" class="form-control" name="username" placeholder="Candidate Name" required="required">
        </div>
        <div class="form-group">
        	<input type="text" class="form-control" name="interviewername" placeholder="Interviewer Name" required="required">
        </div>
		<div class="form-group">
            <input type="text" class="form-control" name="date" placeholder="Date of Interview" required="required">
        </div>
		<div class="form-group">
           <h5> <label for="job title">Interview Type</label></h5>
			<select name="job title" id="title">
    <option value="CV">CV Evaluation</option>
    <option value="Technical Interview">Technical Interview</option>
    <option value="HR Interview">HR Interview</option>
    
  </select>
        </div>     
		<div class="row">
			<div class="col-md-4">
			<h5>Status</h5>
			 <label class="btn btn-default active">
            <input type="radio" name="Status" value="Rejected" checked="">Reject
        </label>
			    </div>
				</div>
		<div class="row">
		<div class="col-md-6">
		<p> Hiring Recommendation after Completion of Evaluation</p>
		</div>
		<div class="col-md-6">
        <input type="radio" id="Hire" name="Recommend" value="Hire" required="required">
          <label for="hire">Hire</label>
          <input type="radio" id="Not Hire" name="Recommend" value="Not Hire">
           <label for="Not Hire">Not Hire</label>
        </div> 		
		
</div>
		 <div class="row">
			<div class="form-group col-md-10">
			<h5>Reviewer Comments</h5>
			<textarea id="comments" name="employercomments" class="form-control" placeholder="Reviewer Comments" required="required"></textarea>
			</div>
			</div>
        <div class="form-group.text-center">
            <input type="submit" class="btn btn-primary btn-block" value="Submit" name="submit"/>
        </div>	
		
      </div>
	  </div>
	  </div>
