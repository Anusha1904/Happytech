<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class feedbackmodel extends CI_Model {

	
	public function feedback()
	{
		
		$this->load->database();
		$Username = $_POST['username'];
		$InterviewerName = $_POST['interviewername'];
		$Date = $_POST['date'];
		$Comments = $_POST['employercomments'];
		$this->load->database();		
		$this->db->query("Insert into evaluation (Username,Interviewer,Date,
		                  Employer Comments)
						  values ('".$Username."','".$InterviewerName."','".$Date."',
						  '".$Comments."')");
			header("Location:http://localhost:8080/Feedback/index.php/Login/home/"); 
           
		 
		}
	
	
	    
	}
