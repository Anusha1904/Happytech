<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Evaluationmodel extends CI_Model {

	
	public function feedback()
	{
		
		$this->load->database();
		$Username = $_POST['username'];
		$EmployerName = $_POST['interviewername'];
		$Date = $_POST['date'];
		$this->load->database();		
		$this->db->query("Insert into test (Username,EmployerName,Date)
						  values ('".$Username."','".$EmployerName."','".$Date."')");
			header("Location:http://localhost:8080/Feedback/index.php/Login/home/"); 
           
		 
		}
	
	
	    
	}
