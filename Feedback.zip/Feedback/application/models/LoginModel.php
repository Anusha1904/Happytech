<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Model {

	
	public function register()
	{
		$this->load->database();
		$Fname = $_POST['first_name'];
		$Lname = $_POST['last_name'];
		$Username = $_POST['username'];
		$Email = $_POST['email'];
		$Password = $_POST['password'];
		$CnfrmPwd = $_POST['confirm_password'];
		$this->db->query("Insert into register ('Fname','Lname,'Username',
		                  'Email','Password','CnfrmPwd') values ('".$Fname."','".$Lname."','".$Username."','".$Email."','".$Password."','".$CnfrmPwd."')
	    echo "Inserted here";		
	}
}
