<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Model {

	
	public function register()
	{
		
		$this->load->database();
		$Fname = $_POST['first_name'];
		$Lname = $_POST['last_name'];
		$Username = $_POST['username'];
		$Email = $_POST['email'];
		$Password = $_POST['password'];
		$Password = md5($Password);
		$this->load->database();		
		$data = $this->db->query("select * from register where Username = '".$Username."'");
		$datarow=$data->row();
		
		if(empty($datarow))
		{
			$this->db->query("Insert into register (Fname,Lname,Username,
		                  Email,Password) values ('".$Fname."','".$Lname."','".$Username."','".$Email."','".$Password."')");
			header("Location:http://localhost:8080/Feedback/index.php/Login"); 
           
		 
		}
	
	
	else
	{
	echo 'Username already exists'; 
	}
		
	    
	}
}
