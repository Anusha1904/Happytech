<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registercontroller extends CI_Controller {

	
	public function register()
	{
        $Fname = $_POST['first_name'];
		$Lname = $_POST['last_name'];
		$Username = $_POST['username'];
		$Email = $_POST['email'];
		$Password = $_POST['password'];
		$this->load->model('Register');
		$this->Register->register();
		
	}
		
}
