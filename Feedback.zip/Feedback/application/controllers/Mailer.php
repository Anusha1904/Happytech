<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Mailer extends CI_Controller{
	function __construct(){
		parent::__construct();
	}
	public function feedbackmail()
	{
		
		$this->load->helper('url');	
		$this->load->view('header');
		$this->load->view('Evaluationview');
		$this->load->view('footer');
	    
	}
	 function send(){
		 print_r($_POST);
		$this->load->helper('url');	
		$data = array ( 
		"Username" => $_POST["username"],
		"EmployerName" =>$_POST["interviewername"],
        "Date" => $_POST["date"],
		"JobTitle"=>$_POST["job_title"] ,
  		"Status"=>$_POST["Status"], 
		"Recommendation"=>$_POST["Recommend"],
		"Comments" => $_POST["employercomments"],
		"Mail" => $_POST["email"]
		);
		$this->load->database();
		$this->db->insert("test",$data);
		
		 $this->load->library('phpmailer_lib');
		 $mail=$this->phpmailer_lib->load();
		 $mail->isSMTP();
		 $mail->Host='smtp.gmail.com';
		 $mail->SMTPAuth='false';
		 $mail->Username = 'anushaupsc5@gmail.com';
		 $mail->Password = 'Anusha@23';
		 $mail->SMTPSecure='tls';
		 $mail->SMTPAutoTLS = false; 
         $mail->Port = 587; 
		 echo $data["Mail"];
		 $mail->setFrom('anushaupsc5@gmail.com','mymail');
		 $mail->addReplyTo('anushaupsc5@gmail.com','mymail');
		 
		 $mail->addAddress($data["Mail"],'mymail');
		 
		 $mail->Subject = 'Sending mail to test';
		 
		 $mail->isHTML(true);
		 $mailContent = "<h1> send HTML Email using SMTP in test</h1>
		                 <p> This is the mail to test mailer function in PHP</p>";
		$mail->Body=$mailContent;	
        
        if(!$mail->send()){
			echo 'Message could not be sent';            
			echo 'Mailer Error: '.$mail->ErrorInfo;
         }else{
			 echo 'Message has been sent';	 
	 }
}
}