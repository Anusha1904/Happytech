<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Evaluation extends CI_Controller {

   public function feedback()
	{
		
		$this->load->helper('url');	
		$this->load->view('header');
		$this->load->view('Evaluationview');
		$this->load->view('footer');
	    
	}
	
	public function evaluationmethod()
	{
		print_r($_POST);
		$this->load->helper('url');	
		$data = array ( 
		"Username" => $_POST["username"],
		"EmployerName" =>$_POST["interviewername"],
        "Date" => $_POST["date"],
		"JobTitle"=>$_POST["job_title"] ,
  		"Status"=>$_POST["Status"], 
		"Recommendation"=>$_POST["Recommend"],
		"Comments" => $_POST["employercomments"]
		);
		$this->load->database();
		$this->db->insert("test",$data);
		redirect("http://localhost:8080/Feedback/index.php/Login/home/");
	}
	}
	
