<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class feedbackcontroller extends CI_Controller {

	
	public function feedback()
	{
		
		$this->load->helper('url');	
		$this->load->view('header');
		$this->load->view('Evaluation');
		$this->load->view('footer');
	    
	}

	public function evaluation()
	{
        $Username = $_POST['username'];
		$InterviewerName = $_POST['interviewername'];
		$Date = $_POST['date'];
		$Comments = $_POST['employercomments'];
		$this->load->model('feedbackmodel');
		$this->feedbackmodel->feedback();
		
	}
		
}
