<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Postjob extends CI_Controller {

	
	public function post()
	{
		
		$this->load->helper('url');	
		$this->load->view('header');
		$this->load->view('Postjob');
		$this->load->view('footer');
	    
	}
	public function addnew()
	{
		$this->load->database();
		$Fname = $_POST['jobtitle'];
		$Lname = $_POST['postedon'];
		$this->load->database();		
		
			$this->db->query("Insert into postjob (JobTitle,Postedon) values ('".$Fname."','".$Lname."')");
			header("Location:http://localhost:8080/Feedback/index.php/Login"); 
           
		 
		}
	
		
	    
	}


