<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Viewapplication extends CI_Controller {

   public function view()
	{
		
		$this->load->helper('url');	
		$this->load->view('header');
		$this->load->view('viewapplication');
		$this->load->view('footer');
	    
	}
	}