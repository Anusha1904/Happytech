<?php session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{
		
		$this->load->view('Loginform');
	}
	public function validation()
	{
		if (isset($_POST['login']))
		{
			$error="";
		$this->load->helper('url');
		$Username = $_POST['username'];
		$Password = $_POST['password'];
		$this->load->database();		
		$data = $this->db->query("select * from login where Username = '".$Username."' AND password='".$Password."'");
		$datarow=$data->row();
    
    if(empty($datarow))  
    {  
        
  redirect("http://localhost:8080/Feedback/index.php/Login");
    }  
    else  
    {  
redirect("http://localhost:8080/Feedback/index.php/Login/home/");
        
      
    }
		}
		
	}
	
	public function home()
	{
		$this->load->helper('url');
		$this->load->view('header');
		$this->load->view('Welcome');
		$this->load->view('footer');
	}
	public function register()
	{
		
		$this->load->helper('url');	
		$this->load->view('Register');
	}
	
}	

