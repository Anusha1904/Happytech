<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Evaluationreject extends CI_Controller {

  public function reject()
	{
		
		$this->load->helper('url');	
		$this->load->view('header');
		$this->load->view('Evaluationrejectview');
		$this->load->view('footer');
	    
	}
	
	public function evaluationreject()
	{
		print_r($_POST);
		$this->load->helper('url');	
		$data = array ( 
		"Username" => $_POST["username"],
		"EmployerName" =>$_POST["interviewername"],
        "Date" => $_POST["date"],
		"JobTitle"=>$_POST["job_title"] ,
  		"Status"=>$_POST["Status"], 
		"Recommendation"=>$_POST["Recommend"],
		"Comments" => $_POST["employercomments"]
		);
		$this->load->database();
		$this->db->insert("test",$data);
		redirect("http://localhost:8080/Feedback/index.php/Login/home/");
	}
	}
	
